"""Builds the JavaScript that is injected into every page of the controlled browser."""

from __future__ import annotations

import json
from importlib import resources

from . import config


def build_init_script(color: str = config.RESPONSE_COLOR, debug: bool = False) -> str:
    cfg = {
        "marker": config.MARKER,
        "color": color,
        "maxFileBytes": config.MAX_FILE_BYTES,
        "debug": debug,
        "sites": [s.to_js() for s in config.SITES],
    }
    js = (resources.files("dlp") / "inject" / "guard.js").read_text(encoding="utf-8")
    return f"window.__WALLED_CONFIG__ = {json.dumps(cfg)};\n{js}"
