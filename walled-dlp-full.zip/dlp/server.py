"""Local IPC server: lets the Electron app drive the existing scanner / guard / dialog code.

Transport
---------
Newline-delimited JSON over this process's **stdin / stdout** - i.e. an anonymous pipe owned by
the Electron parent. There is no TCP port, no socket file and no authentication token to leak:
only the process that spawned us can talk to us, and when it dies the pipe closes and we exit.

    parent -> child   {"id": 7, "op": "prompt", "payload": {"site": "ChatGPT", "text": "..."}}
    child  -> parent  {"id": 7, "ok": true,  "result": {"allow": false}}
                      {"id": 7, "ok": false, "error": {"code": "bad_request", "message": "..."}}
    child  -> parent  {"event": "ready", "protocol": 1, "version": "...", "pid": 123}   (once, at start-up)

Operations (all thin wrappers - no scanning logic lives here)
------------------------------------------------------------
    ping         -> {pong, version, marker, protocol}
    init_script  -> {script}                 page-side hooks built by dlp.injector (same as Playwright mode)
    prompt       {site, text}                -> {allow}      Guard.on_prompt
    file         {site, name, size, b64}     -> {allow}      Guard.on_file
    request      {site, body_b64}            -> {allow}      Guard.on_request   (network safety net)
    shutdown     -> {}                       then the process exits

stdout is reserved for the protocol. At start-up fd 1 is duplicated for protocol use and then
redirected to stderr, so a stray ``print`` or a chatty library (RapidOCR) can never corrupt it.
"""

from __future__ import annotations

import argparse
import asyncio
import base64
import binascii
import json
import logging
import os
import sys
import threading
from typing import Any, Awaitable, Callable, Dict, Optional, TextIO

from . import __version__, config
from .dialog import Detection
from .guard import Guard
from .injector import build_init_script
from .scanner import Scanner

PROTOCOL_VERSION = 1
log = logging.getLogger("dlp.server")


class ProtocolError(Exception):
    """The request was malformed; reported to the caller as ``bad_request``."""


def _req_str(payload: dict, key: str, max_len: int = 256, default: Optional[str] = None) -> str:
    value = payload.get(key, default)
    if not isinstance(value, str):
        raise ProtocolError(f"'{key}' must be a string")
    if len(value) > max_len:
        raise ProtocolError(f"'{key}' is too long")
    return value


class Dispatcher:
    """Pure request -> response logic. No I/O, so it is trivially unit-testable."""

    def __init__(self, guard: Guard, color: str = config.RESPONSE_COLOR, debug: bool = False) -> None:
        self.guard = guard
        self.color = color
        self.debug = debug
        self._ops: Dict[str, Callable[[dict], Awaitable[Any]]] = {
            "ping": self._ping,
            "init_script": self._init_script,
            "prompt": self._prompt,
            "file": self._file,
            "request": self._request,
        }

    async def handle(self, request: Any) -> dict:
        rid = request.get("id") if isinstance(request, dict) else None
        try:
            if not isinstance(request, dict):
                raise ProtocolError("request must be a JSON object")
            if isinstance(rid, bool) or not isinstance(rid, (int, str)):
                raise ProtocolError("'id' must be an integer or string")
            op = request.get("op")
            if not isinstance(op, str):
                raise ProtocolError("'op' must be a string")
            payload = request.get("payload", {})
            if not isinstance(payload, dict):
                raise ProtocolError("'payload' must be an object")
            fn = self._ops.get(op)
            if fn is None:
                return _error(rid, "unknown_op", f"unknown operation '{op}'")
            return {"id": rid, "ok": True, "result": await fn(payload)}
        except ProtocolError as exc:
            return _error(rid, "bad_request", str(exc))
        except Exception as exc:  # noqa: BLE001 - never let one request kill the server
            log.exception("operation failed")
            return _error(rid, "internal", f"{type(exc).__name__}: {exc}")

    # -- operations ------------------------------------------------------ #
    async def _ping(self, _payload: dict) -> dict:
        return {"pong": True, "version": __version__, "marker": config.MARKER, "protocol": PROTOCOL_VERSION}

    async def _init_script(self, _payload: dict) -> dict:
        return {"script": build_init_script(self.color, self.debug)}

    async def _prompt(self, payload: dict) -> dict:
        site = _req_str(payload, "site", 64)
        text = _req_str(payload, "text", max_len=20_000_000)
        return await self.guard.on_prompt({"site": site, "text": text})

    async def _file(self, payload: dict) -> dict:
        site = _req_str(payload, "site", 64)
        name = _req_str(payload, "name", 1024)
        size = payload.get("size", 0)
        if isinstance(size, bool) or not isinstance(size, int) or size < 0:
            raise ProtocolError("'size' must be a non-negative integer")
        b64 = payload.get("b64")
        if b64 is not None and not isinstance(b64, str):
            raise ProtocolError("'b64' must be a string or null")
        return await self.guard.on_file({"site": site, "name": name, "size": size, "b64": b64})

    async def _request(self, payload: dict) -> dict:
        site = _req_str(payload, "site", 64)
        raw = payload.get("body_b64", "")
        if not isinstance(raw, str):
            raise ProtocolError("'body_b64' must be a string")
        try:
            body = base64.b64decode(raw, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise ProtocolError("'body_b64' is not valid base64") from exc
        return {"allow": await self.guard.on_request(site, body)}


def _error(rid: Any, code: str, message: str) -> dict:
    return {"id": rid, "ok": False, "error": {"code": code, "message": message}}


# ---------------------------------------------------------------------------- #
# I/O loop
# ---------------------------------------------------------------------------- #
class Server:
    def __init__(self, dispatcher: Dispatcher, stdin: Any, out: TextIO) -> None:
        self.dispatcher = dispatcher
        self._stdin = stdin
        self._out = out
        self._write_lock = threading.Lock()
        self._tasks: set = set()

    def send(self, message: dict) -> None:
        line = json.dumps(message, separators=(",", ":"))
        with self._write_lock:
            self._out.write(line + "\n")
            self._out.flush()

    async def run(self) -> None:
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue = asyncio.Queue()

        def reader() -> None:  # blocking reads live in a thread: works on every OS
            try:
                for raw in iter(self._stdin.readline, b""):
                    loop.call_soon_threadsafe(queue.put_nowait, raw)
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)   # EOF: parent closed the pipe / died

        threading.Thread(target=reader, name="stdin-reader", daemon=True).start()
        self.send({"event": "ready", "protocol": PROTOCOL_VERSION, "version": __version__, "pid": os.getpid()})

        while True:
            raw = await queue.get()
            if raw is None:
                log.info("stdin closed - shutting down")
                break
            line = raw.strip()
            if not line:
                continue
            try:
                request = json.loads(line)
            except ValueError:
                self.send(_error(None, "bad_json", "request is not valid JSON"))
                continue
            if isinstance(request, dict) and request.get("op") == "shutdown":
                self.send({"id": request.get("id"), "ok": True, "result": {}})
                break
            task = asyncio.create_task(self._serve_one(request))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)

    async def _serve_one(self, request: Any) -> None:
        self.send(await self.dispatcher.handle(request))


# ---------------------------------------------------------------------------- #
# entry point
# ---------------------------------------------------------------------------- #
def _claim_protocol_stream() -> TextIO:
    """Keep the real stdout for the protocol; point fd 1 (and sys.stdout) at stderr."""
    proto = os.fdopen(os.dup(1), "w", encoding="utf-8", newline="\n")
    os.dup2(2, 1)
    sys.stdout = sys.stderr
    return proto


def _auto_dialog(answer: str) -> Callable[[Detection], bool]:
    def dialog(d: Detection) -> bool:
        log.warning("AUTO-ANSWER %s for %s '%s'", answer.upper(), d.kind, d.label[:60])
        return answer == "continue"

    return dialog


def parse_args(argv: Optional[list] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Walled DLP backend (IPC over stdin/stdout)")
    p.add_argument("--color", default=config.RESPONSE_COLOR, help="CSS colour for AI responses")
    p.add_argument("--no-ocr-warmup", action="store_true", help="Do not pre-load OCR models at start-up")
    p.add_argument("--auto-answer", choices=["continue", "cancel"],
                   help="TEST ONLY: answer every confirmation automatically instead of showing the dialog")
    p.add_argument("-v", "--verbose", action="store_true")
    return p.parse_args(argv)


def main(argv: Optional[list] = None) -> int:
    args = parse_args(argv)
    proto = _claim_protocol_stream()
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, stream=sys.stderr,
                        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s", datefmt="%H:%M:%S")
    logging.getLogger("RapidOCR").setLevel(logging.WARNING)

    scanner = Scanner()
    guard = Guard(scanner, dialog=_auto_dialog(args.auto_answer)) if args.auto_answer else Guard(scanner)
    if args.auto_answer:
        log.warning("--auto-answer=%s is for tests only: no dialog will be shown", args.auto_answer)

    if not args.no_ocr_warmup:   # load OCR models in the background so the first image scan is fast
        threading.Thread(target=lambda: scanner.ocr.available, name="ocr-warmup", daemon=True).start()

    server = Server(Dispatcher(guard, color=args.color, debug=args.verbose), sys.stdin.buffer, proto)
    try:
        asyncio.run(server.run())
    except KeyboardInterrupt:
        pass
    # The stdin reader thread may still be blocked in readline(); letting the interpreter tear down
    # around it aborts with "could not acquire lock ... at interpreter shutdown". Everything has been
    # answered and flushed by now, so leave immediately.
    for stream in (proto, sys.stderr):
        try:
            stream.flush()
        except Exception:  # noqa: BLE001
            pass
    os._exit(0)


if __name__ == "__main__":
    sys.exit(main())
