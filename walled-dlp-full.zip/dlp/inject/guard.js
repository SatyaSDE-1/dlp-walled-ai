/*
 * Walled DLP - page-side hooks.
 *
 * Injected into every document of the controlled Chrome *before* any site script runs
 * (Playwright add_init_script). window.__WALLED_CONFIG__ is prepended by dlp/injector.py.
 *
 * What it does
 *   1. Prompts : capture-phase Enter / Send-button hooks. If the prompt contains the marker
 *                the event is swallowed, Python shows the native dialog, and on "Continue"
 *                the original action is replayed. On "Cancel" nothing is replayed, so the
 *                text stays in the box.
 *   2. Files   : capture-phase hooks on <input type=file> change, drag-and-drop and paste.
 *                File bytes go to Python for inspection (text / PDF / OCR). Only the files
 *                the user approved are replayed to the site; denied ones are dropped.
 *   3. Colour  : a constructable stylesheet colours every AI answer. (Constructable sheets
 *                are not subject to the page's CSP, unlike injected <style> tags.)
 *
 * Hooks are on `window` in the capture phase so they run before the site's own listeners.
 * Replayed events are flagged via `bypass` so the hooks never intercept their own replay.
 */
(() => {
  'use strict';

  if (window.top !== window || window.__walledInstalled) return;
  const CFG = window.__WALLED_CONFIG__;
  if (!CFG) return;

  const host = location.hostname.toLowerCase();
  const site = CFG.sites.find((s) => s.hosts.some((h) => host === h || host.endsWith('.' + h)));
  if (!site) return;
  window.__walledInstalled = true;

  const dbg = (...a) => { if (CFG.debug) console.log('[walled-dlp]', ...a); };

  let bypass = false;          // true while we replay an approved action
  let promptPending = false;   // a prompt dialog is currently open

  const replay = (fn) => {
    bypass = true;
    try { fn(); } finally { bypass = false; }
  };

  /* ------------------------------------------------------------------ bridge */
  async function ask(message) {
    if (typeof window.__walledScan !== 'function') {
      console.warn('[walled-dlp] Python bridge unavailable - allowing');
      return true;
    }
    try {
      const reply = await window.__walledScan(message);
      return !!(reply && reply.allow);
    } catch (err) {
      console.warn('[walled-dlp] bridge error - allowing', err);
      return true;
    }
  }

  /* ------------------------------------------------------- 3. response colour */
  function installResponseColor() {
    const list = site.responseSelectors.join(', ');
    const css =
      `:is(${list}), :is(${list}) * {` +
      ` color: ${CFG.color} !important;` +
      ` -webkit-text-fill-color: ${CFG.color} !important; }`;
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(css);
      const apply = () => {
        if (!document.adoptedStyleSheets.includes(sheet)) {
          document.adoptedStyleSheets = [...document.adoptedStyleSheets, sheet];
        }
      };
      apply();
      document.addEventListener('DOMContentLoaded', apply);
    } catch (err) {
      // Very old engines: fall back to a <style> tag.
      const style = document.createElement('style');
      style.textContent = css;
      (document.head || document.documentElement).appendChild(style);
    }
  }

  /* ------------------------------------------------------------ 2. file hooks */
  const readBase64 = (file) =>
    new Promise((resolve) => {
      const fr = new FileReader();
      fr.onload = () => { const s = String(fr.result); resolve(s.slice(s.indexOf(',') + 1)); };
      fr.onerror = () => resolve(null);
      fr.readAsDataURL(file);
    });

  /** Returns the subset of `files` the user is allowed / chose to send. */
  async function filterFiles(files) {
    const allowed = [];
    for (const file of files) {
      const b64 = file.size <= CFG.maxFileBytes ? await readBase64(file) : null;
      const ok = await ask({ kind: 'file', site: site.name, name: file.name, size: file.size, b64 });
      if (ok) allowed.push(file);
    }
    return allowed;
  }

  const toDataTransfer = (files) => {
    const dt = new DataTransfer();
    files.forEach((f) => dt.items.add(f));
    return dt;
  };

  // <input type="file"> - the "Attach / Upload" buttons.
  const pendingInputs = new WeakSet();
  function onFileInput(e) {
    if (bypass) return;
    const input = e.target;
    if (!(input instanceof HTMLInputElement) || input.type !== 'file') return;
    if (!input.files || !input.files.length) return;

    e.stopImmediatePropagation();           // hold back both 'input' and 'change'
    if (pendingInputs.has(input)) return;   // already being inspected
    pendingInputs.add(input);

    const files = Array.from(input.files);
    filterFiles(files).then((allowed) => {
      try {
        if (!allowed.length) { input.value = ''; return; }      // everything cancelled
        if (allowed.length !== files.length) input.files = toDataTransfer(allowed).files;
        replay(() => {
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
        });
      } finally {
        pendingInputs.delete(input);
      }
    });
  }
  window.addEventListener('input', onFileInput, true);
  window.addEventListener('change', onFileInput, true);

  // Drag and drop.
  window.addEventListener('drop', (e) => {
    if (bypass) return;
    const dt = e.dataTransfer;
    if (!dt || !dt.files || !dt.files.length) return;
    e.preventDefault();
    e.stopImmediatePropagation();

    const files = Array.from(dt.files);
    const target = document.contains(e.target) ? e.target : document.body;
    const { clientX, clientY } = e;
    filterFiles(files).then((allowed) => {
      if (!allowed.length) {
        // Let the site's "drop files here" overlay go away.
        replay(() => target.dispatchEvent(new DragEvent('dragleave', { bubbles: true })));
        return;
      }
      replay(() => target.dispatchEvent(new DragEvent('drop', {
        bubbles: true, cancelable: true, composed: true, clientX, clientY,
        dataTransfer: toDataTransfer(allowed),
      })));
    });
  }, true);

  // Pasting files / screenshots into the prompt box.
  window.addEventListener('paste', (e) => {
    if (bypass) return;
    const cd = e.clipboardData;
    if (!cd || !cd.files || !cd.files.length) return;
    e.preventDefault();
    e.stopImmediatePropagation();

    const files = Array.from(cd.files);
    const target = document.contains(e.target) ? e.target : document.body;
    const extras = [];
    for (const type of Array.from(cd.types)) {
      if (type === 'Files') continue;
      try { extras.push([type, cd.getData(type)]); } catch (_) { /* ignore */ }
    }
    filterFiles(files).then((allowed) => {
      if (!allowed.length) return;
      const dt = toDataTransfer(allowed);
      extras.forEach(([t, v]) => dt.setData(t, v));
      replay(() => target.dispatchEvent(new ClipboardEvent('paste', {
        bubbles: true, cancelable: true, composed: true, clipboardData: dt,
      })));
    });
  }, true);

  /* ---------------------------------------------------------- 1. prompt hooks */
  function findEditable(node) {
    let el = node instanceof Element ? node : node && node.parentElement;
    while (el) {
      if (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && /^(text|search)$/i.test(el.type))) return el;
      if (el.isContentEditable) {
        while (el.parentElement && el.parentElement.isContentEditable) el = el.parentElement;
        return el;
      }
      el = el.parentElement;
    }
    return null;
  }

  const closestAny = (el, selectors) =>
    selectors.some((s) => { try { return !!el.closest(s); } catch (_) { return false; } });

  const readText = (el) => ('value' in el && typeof el.value === 'string') ? el.value : (el.innerText || el.textContent || '');

  function findComposerFor(button) {
    const scopes = [button.closest('form'), document].filter(Boolean);
    for (const scope of scopes) {
      for (const sel of site.composerSelectors) {
        const el = scope.querySelector(sel);
        if (el) return el;
      }
    }
    return null;
  }

  function findSendButton(editable) {
    const scopes = [editable && editable.closest('form'), document].filter(Boolean);
    for (const scope of scopes) {
      for (const sel of site.sendSelectors) {
        const btn = scope.querySelector(sel);
        if (btn && !btn.disabled) return btn;
      }
    }
    return null;
  }

  function guardPrompt(text, resume) {
    if (promptPending) return;              // swallow extra Enter presses while a dialog is open
    promptPending = true;
    ask({ kind: 'prompt', site: site.name, text }).then((ok) => {
      promptPending = false;
      if (ok) resume();
    });
  }

  const swallow = (e) => { e.preventDefault(); e.stopImmediatePropagation(); };

  // Enter key in the prompt box.
  window.addEventListener('keydown', (e) => {
    if (bypass || !e.isTrusted) return;
    if (e.key !== 'Enter' || e.shiftKey || e.altKey || e.isComposing) return;
    const editable = findEditable(e.target);
    if (!editable || !closestAny(editable, site.composerSelectors)) return;
    const text = readText(editable);
    if (!text.includes(CFG.marker)) return;     // fast path: nothing sensitive, don't touch the event

    swallow(e);
    if (e.repeat) return;
    guardPrompt(text, () => {
      const btn = findSendButton(editable);
      replay(() => {
        if (btn) { btn.click(); return; }
        editable.dispatchEvent(new KeyboardEvent('keydown', {
          key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true,
        }));
      });
    });
  }, true);

  // Click on the send button.
  window.addEventListener('click', (e) => {
    if (bypass || !e.isTrusted || !(e.target instanceof Element)) return;
    const button = e.target.closest(site.sendSelectors.join(','));
    if (!button) return;
    const editable = findComposerFor(button);
    if (!editable) return;
    const text = readText(editable);
    if (!text.includes(CFG.marker)) return;

    swallow(e);
    guardPrompt(text, () => replay(() => button.click()));
  }, true);

  /* -------------------------------------------------------------------- init */
  installResponseColor();
  dbg('installed on', site.name);
})();
