"""Central configuration.

Everything that is site-specific (URLs, DOM selectors, API endpoints) lives here so
that when ChatGPT or Perplexity change their markup, only this file needs touching.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Pattern

# --------------------------------------------------------------------------- #
# Policy
# --------------------------------------------------------------------------- #
MARKER = "WALLED_SENSITIVE"

# Colour applied to every AI-generated response (any valid CSS colour).
RESPONSE_COLOR = "#d00000"

# Files larger than this are not inspected (they are allowed through, with a warning).
MAX_FILE_BYTES = 30 * 1024 * 1024

# Upper bounds on OCR work per file so a huge PDF cannot freeze the app.
MAX_OCR_IMAGES_PER_PDF = 25
MAX_PDF_PAGES_RENDERED = 15

# How long (seconds) a user's "Continue" on a prompt is remembered so the network
# safety-net does not ask the same question a second time for the same prompt.
APPROVAL_TTL_SECONDS = 180

# --------------------------------------------------------------------------- #
# Browser / CDP
# --------------------------------------------------------------------------- #
CDP_PORT = 9222
PROFILE_DIR = Path(os.environ.get("WALLED_DLP_PROFILE", Path.home() / ".walled-dlp" / "chrome-profile"))


# --------------------------------------------------------------------------- #
# Supported sites
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Site:
    name: str
    hosts: List[str]
    start_url: str
    # The prompt box. Used to decide "is this Enter key a prompt submission?".
    composer_selectors: List[str]
    # The send / submit button(s).
    send_selectors: List[str]
    # Containers holding AI-generated answers. Colour is applied to them and descendants.
    response_selectors: List[str]
    # Network endpoints that carry a prompt to the model (safety net, see guard.py).
    api_patterns: List[Pattern[str]] = field(default_factory=list)

    def to_js(self) -> dict:
        return {
            "name": self.name,
            "hosts": self.hosts,
            "composerSelectors": self.composer_selectors,
            "sendSelectors": self.send_selectors,
            "responseSelectors": self.response_selectors,
        }


CHATGPT = Site(
    name="ChatGPT",
    hosts=["chatgpt.com"],
    start_url="https://chatgpt.com/",
    composer_selectors=[
        "#prompt-textarea",
        "#mobile-composer-prompt",
        "textarea[id$='-composer-prompt']",
        "div.ProseMirror[contenteditable='true']",
    ],
    send_selectors=[
        "[data-testid='send-button']",
        "button[aria-label='Send prompt']",
        "button[aria-label='Send message']",
        "button[aria-label*='Send' i]",
    ],
    response_selectors=[
        "[data-message-role='assistant']",
        "[data-message-author-role='assistant']",
        "[data-turn='assistant']",
        "article[data-turn='assistant']",
        "div[data-testid='conversation-turn-content']",
        "div[data-testid*='conversation-turn']",
        "[data-testid*='assistant']",
        "div[class*='markdown']",
    ],
    api_patterns=[re.compile(r"^https://chatgpt\.com/backend-(api|anon)/(f/)?conversation(\?.*)?$")],
)

PERPLEXITY = Site(
    name="Perplexity",
    hosts=["perplexity.ai"],
    start_url="https://www.perplexity.ai/",
    composer_selectors=["#ask-input", "div[contenteditable='true'][role='textbox']", "textarea"],
    send_selectors=[
        "button[aria-label='Submit']",
        "button[data-testid='submit-button']",
        "button[aria-label='Send']",
    ],
    response_selectors=[
        "[id^='markdown-content-']",
        "div.prose",
        "[data-testid='answer']",
    ],
    api_patterns=[re.compile(r"^https://www\.perplexity\.ai/rest/sse/perplexity_ask(\?.*)?$")],
)

SITES: List[Site] = [CHATGPT, PERPLEXITY]


def site_for_url(url: str) -> Site | None:
    from urllib.parse import urlparse

    host = (urlparse(url).hostname or "").lower()
    for site in SITES:
        if any(host == h or host.endswith("." + h) for h in site.hosts):
            return site
    return None
