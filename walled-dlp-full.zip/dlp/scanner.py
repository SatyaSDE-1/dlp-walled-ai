"""Sensitive-marker detection for prompts and files (text, PDF, images).

Matching rules
--------------
* Prompts and plain-text content: exact, case-sensitive match of ``WALLED_SENSITIVE``.
* Text that comes out of PDF extraction or OCR is matched *tolerantly*
  (``WALLED SENSITIVE``, ``WALLED-SENSITIVE`` ...) because extraction and OCR routinely
  turn an underscore into a space or drop it altogether.

The scanner never raises on malformed input: a file it cannot parse yields
``ScanResult(found=False, error=...)`` and the caller decides what to do.
"""

from __future__ import annotations

import io
import logging
import re
import zipfile
from dataclasses import dataclass
from typing import Optional

from . import config
from .ocr import OcrEngine

log = logging.getLogger("dlp.scanner")

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".tif", ".tiff"}


@dataclass
class ScanResult:
    found: bool
    file_type: str = "unknown"      # text | pdf | image | archive | binary | empty
    where: str = ""                 # human-readable hint: "page 2", "OCR", ...
    error: Optional[str] = None


class Scanner:
    def __init__(self, marker: str = config.MARKER, ocr: Optional[OcrEngine] = None) -> None:
        self.marker = marker
        self.ocr = ocr or OcrEngine()
        # Tolerant pattern built from the marker: WALLED_SENSITIVE -> WALLED[\s_.-]{0,3}SENSITIVE
        parts = [re.escape(p) for p in re.split(r"[_\s]+", marker) if p]
        self._fuzzy = re.compile(r"[\s_.\-]{0,3}".join(parts), re.IGNORECASE)
        self._raw_variants = [marker.encode(enc) for enc in ("utf-8", "utf-16-le", "utf-16-be")]

    # ------------------------------------------------------------------ #
    # Text
    # ------------------------------------------------------------------ #
    def scan_text(self, text: str) -> bool:
        """Exact match - used for typed prompts."""
        return self.marker in text

    def _fuzzy_hit(self, text: str) -> bool:
        return bool(text) and (self.marker in text or self._fuzzy.search(text) is not None)

    # ------------------------------------------------------------------ #
    # Files
    # ------------------------------------------------------------------ #
    def scan_file(self, name: str, data: bytes) -> ScanResult:
        if not data:
            return ScanResult(False, "empty")
        try:
            kind = sniff_type(name, data)
            if kind == "pdf":
                return self._scan_pdf(data)
            if kind == "image":
                return self._scan_image(data)
            if kind == "archive":
                return self._scan_archive(data)
            return self._scan_text_bytes(data, kind)
        except Exception as exc:  # noqa: BLE001
            log.exception("Scan failed for %s", name)
            return ScanResult(False, "unknown", error=str(exc))

    # -- text / generic bytes ------------------------------------------- #
    def _raw_hit(self, data: bytes) -> bool:
        return any(v in data for v in self._raw_variants)

    def _scan_text_bytes(self, data: bytes, kind: str) -> ScanResult:
        if self._raw_hit(data):
            return ScanResult(True, kind, "file contents")
        return ScanResult(False, kind)

    # -- PDF -------------------------------------------------------------- #
    def _scan_pdf(self, data: bytes) -> ScanResult:
        from pypdf import PdfReader

        # Cheap pass: uncompressed streams / metadata.
        if self._raw_hit(data):
            return ScanResult(True, "pdf", "PDF contents")

        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            try:
                reader.decrypt("")
            except Exception:  # noqa: BLE001
                return ScanResult(False, "pdf", error="encrypted PDF could not be opened")

        meta = " ".join(str(v) for v in (reader.metadata or {}).values())
        if self._fuzzy_hit(meta):
            return ScanResult(True, "pdf", "PDF metadata")

        pages_without_text = []
        ocr_budget = config.MAX_OCR_IMAGES_PER_PDF

        for idx, page in enumerate(reader.pages, start=1):
            text = ""
            try:
                text = page.extract_text() or ""
            except Exception as exc:  # noqa: BLE001
                log.debug("extract_text failed on page %d: %s", idx, exc)
            if self._fuzzy_hit(text):
                return ScanResult(True, "pdf", f"page {idx} text")
            if len(text.strip()) < 20:
                pages_without_text.append(idx - 1)

            # Embedded images (scans, screenshots pasted into a PDF).
            if ocr_budget > 0:
                try:
                    images = list(page.images)
                except Exception:  # noqa: BLE001
                    images = []
                for img in images:
                    if ocr_budget <= 0:
                        break
                    ocr_budget -= 1
                    pil = _open_image(img.data)
                    if pil is not None and self._fuzzy_hit(self.ocr.read(pil)):
                        return ScanResult(True, "pdf", f"page {idx} image (OCR)")

        # Pages with no extractable text and no embedded image may be vector-drawn text;
        # render them and OCR the result.
        if pages_without_text and self.ocr.available:
            hit = self._scan_rendered_pages(data, pages_without_text)
            if hit:
                return ScanResult(True, "pdf", hit)

        return ScanResult(False, "pdf")

    def _scan_rendered_pages(self, data: bytes, page_indexes: list) -> Optional[str]:
        try:
            import pypdfium2 as pdfium
        except ImportError:
            return None
        pdf = pdfium.PdfDocument(data)
        try:
            for i in page_indexes[: config.MAX_PDF_PAGES_RENDERED]:
                pil = pdf[i].render(scale=2.0).to_pil()
                if self._fuzzy_hit(self.ocr.read(pil)):
                    return f"page {i + 1} (rendered + OCR)"
        finally:
            pdf.close()
        return None

    # -- images ------------------------------------------------------------ #
    def _scan_image(self, data: bytes) -> ScanResult:
        # EXIF / PNG text chunks / appended payloads are caught by the raw pass.
        if self._raw_hit(data):
            return ScanResult(True, "image", "image metadata")
        pil = _open_image(data)
        if pil is None:
            return ScanResult(False, "image", error="could not decode image")
        if not self.ocr.available:
            return ScanResult(False, "image", error="no OCR back-end available")
        frames = _frames(pil)
        for frame in frames:
            if self._fuzzy_hit(self.ocr.read(frame)):
                return ScanResult(True, "image", "text in image (OCR)")
        return ScanResult(False, "image")

    # -- zip-based containers (docx, xlsx, pptx, zip) -------------------- #
    def _scan_archive(self, data: bytes, depth: int = 0) -> ScanResult:
        budget = 60 * 1024 * 1024
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            for info in zf.infolist():
                if info.is_dir() or info.file_size > budget:
                    continue
                budget -= info.file_size
                member = zf.read(info)
                if self._raw_hit(member):
                    return ScanResult(True, "archive", f"inside '{info.filename}'")
        return ScanResult(False, "archive")


# ---------------------------------------------------------------------------- #
# helpers
# ---------------------------------------------------------------------------- #
def sniff_type(name: str, data: bytes) -> str:
    head = data[:16]
    ext = ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""
    if data[:1024].lstrip().startswith(b"%PDF-") or b"%PDF-" in data[:1024]:
        return "pdf"
    if (
        head.startswith((b"\x89PNG", b"\xff\xd8\xff", b"GIF8", b"BM", b"II*\x00", b"MM\x00*"))
        or (head[:4] == b"RIFF" and data[8:12] == b"WEBP")
        or ext in IMAGE_EXTENSIONS and _open_image(data) is not None
    ):
        return "image"
    if head.startswith(b"PK\x03\x04"):
        return "archive"
    return "text" if _looks_textual(data) else "binary"


def _looks_textual(data: bytes) -> bool:
    sample = data[:8192]
    if sample.startswith((b"\xff\xfe", b"\xfe\xff", b"\xef\xbb\xbf")):
        return True
    return b"\x00" not in sample


def _open_image(data: bytes):
    try:
        from PIL import Image

        img = Image.open(io.BytesIO(data))
        img.load()
        return img
    except Exception:  # noqa: BLE001
        return None


def _frames(img, limit: int = 5):
    """Yield up to ``limit`` frames of a (possibly animated) image."""
    n = getattr(img, "n_frames", 1)
    out = []
    for i in range(min(n, limit)):
        try:
            img.seek(i)
            out.append(img.copy())
        except EOFError:
            break
    return out or [img]
