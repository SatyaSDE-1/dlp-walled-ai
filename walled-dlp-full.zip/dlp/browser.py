"""Chrome launcher + Playwright (CDP) wiring.

We do not proxy traffic or patch the site. Instead we start - or attach to - a real Chrome
with ``--remote-debugging-port`` and drive it over the Chrome DevTools Protocol:

* ``context.add_init_script``  -> page-side hooks run before any site code (guard.js)
* ``context.expose_function``  -> JS calls ``window.__walledScan(...)`` and Python answers
* ``context.route``            -> pauses the prompt-carrying HTTP request (safety net)
"""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from typing import Optional

from playwright.async_api import Browser, BrowserContext, Page, Route, async_playwright

from . import config
from .guard import Guard
from .injector import build_init_script

log = logging.getLogger("dlp.browser")


# ---------------------------------------------------------------------------- #
# Chrome process management
# ---------------------------------------------------------------------------- #
def find_chrome(explicit: Optional[str] = None) -> str:
    candidates = [explicit, os.environ.get("CHROME_PATH")]
    if sys.platform == "darwin":
        candidates += [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            str(Path.home() / "Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        ]
    elif sys.platform.startswith("win"):
        roots = [os.environ.get(k, "") for k in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")]
        candidates += [os.path.join(r, p) for r in roots if r
                       for p in (r"Google\Chrome\Application\chrome.exe",
                                 r"Microsoft\Edge\Application\msedge.exe")]
    else:
        candidates += [shutil.which(n) for n in
                       ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge")]
    for c in candidates:
        if c and Path(c).exists():
            return str(c)
    raise FileNotFoundError(
        "Chrome was not found. Install Google Chrome or pass --chrome-path / set CHROME_PATH."
    )


def cdp_alive(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=1.5):
            return True
    except Exception:  # noqa: BLE001
        return False


def launch_chrome(port: int, chrome_path: Optional[str] = None, extra_args: Optional[list] = None) -> subprocess.Popen:
    exe = find_chrome(chrome_path)
    config.PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    args = [
        exe,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={config.PROFILE_DIR}",   # Chrome >= 136 refuses debugging on the default profile
        "--no-first-run",
        "--no-default-browser-check",
        *(extra_args or []),
        "about:blank",
    ]
    log.info("Launching Chrome: %s", exe)
    kwargs = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if sys.platform.startswith("win"):
        kwargs["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
    else:
        kwargs["start_new_session"] = True
    proc = subprocess.Popen(args, **kwargs)

    deadline = time.monotonic() + 25
    while time.monotonic() < deadline:
        if cdp_alive(port):
            return proc
        if proc.poll() is not None:
            break
        time.sleep(0.3)
    raise RuntimeError(
        f"Chrome did not open the debugging port {port}. If another Chrome is already using the "
        f"'{config.PROFILE_DIR}' profile, quit it and try again."
    )


# ---------------------------------------------------------------------------- #
# Session
# ---------------------------------------------------------------------------- #
class BrowserSession:
    def __init__(self, guard: Guard, port: int = config.CDP_PORT, color: str = config.RESPONSE_COLOR,
                 debug: bool = False) -> None:
        self.guard = guard
        self.port = port
        self.color = color
        self.debug = debug
        self._pw = None
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.disconnected = asyncio.Event()

    async def start(self, open_sites: bool = True, reload_existing: bool = True) -> None:
        self._pw = await async_playwright().start()
        self.browser = await self._pw.chromium.connect_over_cdp(
            f"http://127.0.0.1:{self.port}",
            no_defaults=True,
        )
        self.browser.on("disconnected", lambda *_: self.disconnected.set())
        self.context = self.browser.contexts[0] if self.browser.contexts else await self.browser.new_context()
        await self.install(self.context)

        pages = list(self.context.pages)
        if reload_existing:
            for page in pages:
                if config.site_for_url(page.url):
                    log.info("Reloading existing tab so protection applies: %s", page.url)
                    await page.reload()
        if open_sites and not any(config.site_for_url(p.url) for p in pages):
            for site in config.SITES:
                page = await self.context.new_page()
                await page.goto(site.start_url, wait_until="commit")

    async def install(self, context: BrowserContext) -> None:
        """Attach every hook to a browser context (also used directly by the tests)."""
        await context.expose_function("__walledScan", self._on_bridge_call)
        await context.add_init_script(build_init_script(self.color, self.debug))
        for site in config.SITES:
            for pattern in site.api_patterns:
                await context.route(pattern, self._make_route_handler(site.name))

    async def stop(self) -> None:
        if self._pw:
            await self._pw.stop()

    # ------------------------------------------------------------------ #
    async def _on_bridge_call(self, message: dict) -> dict:
        kind = message.get("kind")
        try:
            if kind == "prompt":
                return await self.guard.on_prompt(message)
            if kind == "file":
                return await self.guard.on_file(message)
        except Exception:  # noqa: BLE001
            log.exception("Guard error handling %s - allowing", kind)
        return {"allow": True}

    def _make_route_handler(self, site_name: str):
        async def handler(route: Route) -> None:
            request = route.request
            if request.method != "POST":
                await route.fallback()
                return
            try:
                body = request.post_data_buffer or b""
                allowed = await self.guard.on_request(site_name, body)
            except Exception:  # noqa: BLE001
                log.exception("Safety-net error - letting the request through")
                allowed = True
            if allowed:
                await route.fallback()
            else:
                await route.abort("blockedbyclient")

        return handler
