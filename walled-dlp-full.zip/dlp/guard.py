"""Decision engine: scan -> ask the user -> allow / block.

The browser layer (browser.py) forwards three kinds of events here:

* ``on_prompt``   - from the injected JS, when the user presses Enter / Send with the
                    marker in the prompt box.
* ``on_file``     - from the injected JS, for every file about to be attached.
* ``on_request``  - from the network safety-net, for the HTTP request that carries a prompt
                    to the model (catches submit paths the DOM hooks cannot see).

Everything that talks to the user goes through ``self._ask`` which serialises dialogs
(only one on screen at a time) and runs the blocking native dialog off the event loop.
"""

from __future__ import annotations

import asyncio
import base64
import binascii
import json
import logging
import time
from typing import Callable, Iterable, List

from . import config
from .dialog import Detection, confirm
from .scanner import Scanner

log = logging.getLogger("dlp.guard")


def _norm(s: str) -> str:
    return " ".join(s.split())


class ApprovalCache:
    """Remembers prompts the user already approved, per site, for a short time.

    Approving a prompt on ChatGPT must never pre-approve the same text on Perplexity,
    hence the (site, text) key.
    """

    def __init__(self, ttl: float = config.APPROVAL_TTL_SECONDS) -> None:
        self.ttl = ttl
        self._items: List[tuple] = []  # (expires_at, site, normalised_text)

    def add(self, site: str, text: str) -> None:
        self._purge()
        self._items.append((time.monotonic() + self.ttl, site, _norm(text)))

    def contains(self, site: str, text: str) -> bool:
        self._purge()
        t = _norm(text)
        return any(s == site and (a == t or a in t) for _, s, a in self._items)

    def _purge(self) -> None:
        now = time.monotonic()
        self._items = [i for i in self._items if i[0] > now]


class Guard:
    def __init__(self, scanner: Scanner | None = None,
                 dialog: Callable[[Detection], bool] = confirm) -> None:
        self.scanner = scanner or Scanner()
        self._dialog = dialog
        self._dialog_lock = asyncio.Lock()
        self.approvals = ApprovalCache()

    # ------------------------------------------------------------------ #
    # Entry points
    # ------------------------------------------------------------------ #
    async def on_prompt(self, payload: dict) -> dict:
        """payload: {site, text}"""
        text = str(payload.get("text", ""))
        site = str(payload.get("site", "?"))
        if not self.scanner.scan_text(text):
            return {"allow": True}
        allow = await self._ask(Detection("prompt", site, text))
        if allow:
            self.approvals.add(site, text)
        log.info("[%s] prompt with marker -> %s", site, "CONTINUE" if allow else "CANCEL")
        return {"allow": allow}

    async def on_file(self, payload: dict) -> dict:
        """payload: {site, name, size, b64}   (b64 omitted when the file is too large)"""
        name = str(payload.get("name", "file"))
        site = str(payload.get("site", "?"))
        size = int(payload.get("size") or 0)

        b64 = payload.get("b64")
        if not b64:
            log.warning("[%s] '%s' (%s bytes) was not inspected (too large / unreadable) - allowed",
                        site, name, size)
            return {"allow": True}
        try:
            data = base64.b64decode(b64, validate=False)
        except (binascii.Error, ValueError):
            log.warning("[%s] could not decode payload for '%s' - allowed", site, name)
            return {"allow": True}

        result = await asyncio.to_thread(self.scanner.scan_file, name, data)
        if result.error:
            log.warning("[%s] '%s': scan problem: %s", site, name, result.error)
        if not result.found:
            log.info("[%s] file '%s' clean (%s)", site, name, result.file_type)
            return {"allow": True}

        allow = await self._ask(Detection("file", site, name, result.where, result.file_type, size))
        log.info("[%s] file '%s' (%s, %s) -> %s", site, name, result.file_type, result.where,
                 "CONTINUE" if allow else "CANCEL")
        return {"allow": allow}

    async def on_request(self, site: str, body: bytes) -> bool:
        """Network safety-net. Returns True if the request may be sent."""
        text = body.decode("utf-8", errors="ignore")
        if not self.scanner.scan_text(text):
            return True
        hits = [s for s in _json_strings(text) if self.scanner.scan_text(s)] or [text]
        if all(self.approvals.contains(site, h) for h in hits):
            return True  # user already said Continue in the page
        allow = await self._ask(Detection("prompt", site, hits[0]))
        if allow:
            for h in hits:
                self.approvals.add(site, h)
        log.info("[%s] network request with marker -> %s", site, "CONTINUE" if allow else "CANCEL")
        return allow

    # ------------------------------------------------------------------ #
    async def _ask(self, detection: Detection) -> bool:
        async with self._dialog_lock:
            return await asyncio.to_thread(self._dialog, detection)


def _json_strings(raw: str) -> Iterable[str]:
    """Yield every string value in a JSON document (or nothing if it isn't JSON)."""
    try:
        doc = json.loads(raw)
    except ValueError:
        return
    stack = [doc]
    while stack:
        node = stack.pop()
        if isinstance(node, str):
            yield node
        elif isinstance(node, dict):
            stack.extend(node.values())
        elif isinstance(node, list):
            stack.extend(node)
