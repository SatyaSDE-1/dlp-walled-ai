"""Optional OCR layer used to look for the marker inside images and scanned PDFs.

Two interchangeable back-ends are supported and chosen lazily at first use:

1. ``rapidocr``  - pure ``pip`` install (ONNX models ship inside the wheel). Default.
2. ``pytesseract`` - used if RapidOCR is missing and the ``tesseract`` binary exists.

If neither is available, :meth:`OcrEngine.read` returns an empty string and the caller
logs a warning; the rest of the application keeps working.
"""

from __future__ import annotations

import logging
import shutil
import threading
from typing import Callable, Optional

log = logging.getLogger("dlp.ocr")


class OcrEngine:
    def __init__(self) -> None:
        self._lock = threading.Lock()  # OCR runtimes are not guaranteed thread-safe
        self._fn: Optional[Callable] = None
        self._name = "none"
        self._initialised = False

    # ------------------------------------------------------------------ #
    @property
    def name(self) -> str:
        self._init()
        return self._name

    @property
    def available(self) -> bool:
        self._init()
        return self._fn is not None

    def read(self, image) -> str:
        """Return the text found in a PIL image ('' if OCR is unavailable)."""
        self._init()
        if self._fn is None:
            return ""
        image = _prepare(image)
        with self._lock:
            try:
                return self._fn(image) or ""
            except Exception as exc:  # noqa: BLE001 - OCR must never crash the app
                log.warning("OCR failed (%s): %s", self._name, exc)
                return ""

    # ------------------------------------------------------------------ #
    def _init(self) -> None:
        if self._initialised:
            return
        with self._lock:
            if self._initialised:
                return
            self._initialised = True
            for loader in (self._load_rapidocr, self._load_tesseract):
                try:
                    if loader():
                        break
                except Exception as exc:  # noqa: BLE001
                    log.debug("OCR back-end failed to load: %s", exc)
            if self._fn is None:
                log.warning("No OCR back-end available - images / scanned PDFs cannot be inspected. "
                            "Install with: pip install rapidocr")
            else:
                log.info("OCR back-end: %s", self._name)

    def _load_rapidocr(self) -> bool:
        import numpy as np

        try:  # rapidocr >= 2 (current package name)
            from rapidocr import RapidOCR

            engine = RapidOCR()

            def run(img) -> str:
                out = engine(np.array(img))
                txts = getattr(out, "txts", None)
                return "\n".join(txts) if txts else ""

        except ImportError:  # legacy package name
            from rapidocr_onnxruntime import RapidOCR  # type: ignore

            engine = RapidOCR()

            def run(img) -> str:  # type: ignore[misc]
                result, _ = engine(np.array(img))
                return "\n".join(r[1] for r in result) if result else ""

        self._fn, self._name = run, "rapidocr"
        return True

    def _load_tesseract(self) -> bool:
        if not shutil.which("tesseract"):
            return False
        import pytesseract

        self._fn = lambda img: pytesseract.image_to_string(img)
        self._name = "tesseract"
        return True


def _prepare(image):
    """Normalise a PIL image for OCR: RGB, flatten transparency, upscale tiny images."""
    from PIL import Image

    if image.mode in ("RGBA", "LA", "P"):
        image = image.convert("RGBA")
        bg = Image.new("RGBA", image.size, (255, 255, 255, 255))
        bg.alpha_composite(image)
        image = bg
    image = image.convert("RGB")
    if image.width < 900:
        scale = 900 / image.width
        image = image.resize((900, max(1, int(image.height * scale))), Image.LANCZOS)
    return image
