"""Native desktop confirmation dialog.

Platform strategy (all produce a real OS window - never an in-browser popup):

* macOS   : ``osascript`` -> AppleScript ``display dialog`` (Continue / Cancel buttons)
* Linux   : ``zenity`` or ``kdialog`` when installed
* Windows : Tk window (``dlp/dialog_tk.py``) run in a child process
* fallback: the same Tk window on any platform where the above is unavailable

``confirm`` is blocking and returns ``True`` for *Continue* and ``False`` for *Cancel*.
Any failure to show the dialog returns ``False`` - for a DLP tool, failing closed (block)
is the safe default.
"""

from __future__ import annotations

import html
import logging
import shutil
import subprocess
import sys
from dataclasses import dataclass
from typing import List, Optional

log = logging.getLogger("dlp.dialog")

TITLE = "Walled DLP - Sensitive content detected"
CONTINUE = "Continue"
CANCEL = "Cancel"
PREVIEW_CHARS = 280


@dataclass
class Detection:
    kind: str                 # "prompt" | "file"
    site: str                 # "ChatGPT" | "Perplexity"
    label: str                # prompt text, or file name
    detail: str = ""          # e.g. "page 2 text", "text in image (OCR)"
    file_type: str = ""       # "pdf" | "image" | "text" ...
    size: Optional[int] = None


def build_message(d: Detection) -> str:
    """Plain-text body shared by every dialog back-end."""
    if d.kind == "prompt":
        preview = " ".join(d.label.split())
        if len(preview) > PREVIEW_CHARS:
            preview = preview[:PREVIEW_CHARS].rstrip() + "..."
        lines = [
            "Sensitive content was detected in a TEXT PROMPT.",
            "",
            f"Destination: {d.site}",
            f"Prompt: \"{preview}\"",
        ]
    else:
        kind = f" ({d.file_type})" if d.file_type else ""
        lines = [
            "Sensitive content was detected in a FILE.",
            "",
            f"Destination: {d.site}",
            f"File name: {d.label}{kind}",
        ]
        if d.size is not None:
            lines.append(f"Size: {_human(d.size)}")
        if d.detail:
            lines.append(f"Found in: {d.detail}")
    lines += ["", f"Choose \"{CONTINUE}\" to send it anyway, or \"{CANCEL}\" to block it."]
    return "\n".join(lines)


def confirm(d: Detection) -> bool:
    message = build_message(d)
    try:
        if sys.platform == "darwin":
            return _mac(message)
        if sys.platform.startswith("linux"):
            result = _linux(message)
            if result is not None:
                return result
        return _tk(d, message)
    except Exception as exc:  # noqa: BLE001
        log.error("Could not display confirmation dialog (%s) - blocking by default", exc)
        return False


# ---------------------------------------------------------------------------- #
# back-ends
# ---------------------------------------------------------------------------- #
def _mac(message: str) -> bool:
    script = [
        "on run argv",
        'set r to display dialog (item 1 of argv) with title (item 2 of argv) '
        f'buttons {{"{CANCEL}", "{CONTINUE}"}} default button "{CANCEL}" cancel button "{CANCEL}" '
        "with icon caution",
        "return button returned of r",
        "end run",
    ]
    cmd: List[str] = ["osascript"]
    for line in script:
        cmd += ["-e", line]
    cmd += ["--", message, TITLE]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    # Pressing Cancel makes osascript exit non-zero (error -128), which is exactly "cancel".
    return proc.returncode == 0 and proc.stdout.strip() == CONTINUE


def _linux(message: str) -> Optional[bool]:
    if shutil.which("zenity"):
        proc = subprocess.run(
            ["zenity", "--question", "--title", TITLE, "--text", html.escape(message),
             "--ok-label", CONTINUE, "--cancel-label", CANCEL, "--width", "480"]
        )
        return proc.returncode == 0
    if shutil.which("kdialog"):
        proc = subprocess.run(
            ["kdialog", "--title", TITLE, "--yes-label", CONTINUE, "--no-label", CANCEL,
             "--warningyesno", message.replace("\n", "<br>")]
        )
        return proc.returncode == 0
    return None


def _tk(d: Detection, message: str) -> bool:
    proc = subprocess.run([sys.executable, "-m", "dlp.dialog_tk", TITLE, message, CONTINUE, CANCEL])
    return proc.returncode == 0


def _human(n: int) -> str:
    size = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{n} B"
