import io
import zipfile

import pytest

from dlp.scanner import Scanner, sniff_type
from samples import make_samples as ms

M = ms.MARKER


@pytest.fixture(scope="module")
def scanner():
    return Scanner()


# ---------------------------------------------------------------- prompts / text
def test_prompt_exact_match(scanner):
    assert scanner.scan_text(f"please summarise {M} for me")
    assert not scanner.scan_text("an ordinary prompt")
    assert not scanner.scan_text("walled_sensitive")          # case-sensitive for typed text


def test_text_file(scanner):
    assert scanner.scan_file("a.txt", ms.SENSITIVE_BODY.encode()).found
    assert not scanner.scan_file("a.txt", ms.CLEAN_BODY.encode()).found


def test_utf16_text_file(scanner):
    assert scanner.scan_file("u16.txt", f"hello {M}".encode("utf-16")).found


def test_source_code_and_unknown_extension(scanner):
    assert scanner.scan_file("notes", f"# {M}\nprint(1)".encode()).found


def test_empty_file(scanner):
    r = scanner.scan_file("e.txt", b"")
    assert not r.found and r.file_type == "empty"


# ----------------------------------------------------------------------- PDF
def test_pdf_text_layer(scanner):
    r = scanner.scan_file("s.pdf", ms.pdf_with_text(ms.SENSITIVE_BODY))
    assert r.found and r.file_type == "pdf"


def test_pdf_clean(scanner):
    assert not scanner.scan_file("c.pdf", ms.pdf_with_text(ms.CLEAN_BODY)).found


def test_pdf_scanned_needs_ocr(scanner):
    r = scanner.scan_file("scan.pdf", ms.pdf_from_image(ms.SENSITIVE_BODY))
    assert r.found and "OCR" in r.where


def test_pdf_wrong_extension_still_detected(scanner):
    assert scanner.scan_file("report.txt", ms.pdf_with_text(ms.SENSITIVE_BODY)).found


def test_corrupt_pdf_does_not_raise(scanner):
    r = scanner.scan_file("bad.pdf", b"%PDF-1.4\nthis is not really a pdf")
    assert not r.found


# --------------------------------------------------------------------- images
@pytest.mark.parametrize("fmt,name", [("PNG", "s.png"), ("JPEG", "s.jpg")])
def test_image_with_marker(scanner, fmt, name):
    r = scanner.scan_file(name, ms.image_bytes(ms.SENSITIVE_BODY, fmt))
    assert r.found and r.file_type == "image"


def test_image_clean(scanner):
    assert not scanner.scan_file("c.png", ms.image_bytes(ms.CLEAN_BODY, "PNG")).found


def test_ocr_tolerates_space_instead_of_underscore(scanner):
    img = ms.image_bytes("Top secret\nWALLED SENSITIVE data", "PNG")
    assert scanner.scan_file("x.png", img).found


# -------------------------------------------------------------------- archives
def test_docx_like_zip(scanner):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("word/document.xml", f"<w:t>{M}</w:t>")
    r = scanner.scan_file("a.docx", buf.getvalue())
    assert r.found and r.file_type == "archive"


def test_sniffing():
    assert sniff_type("x", b"%PDF-1.7 ...") == "pdf"
    assert sniff_type("x", b"\x89PNG\r\n\x1a\n....") == "image"
    assert sniff_type("x", b"just text") == "text"
    assert sniff_type("x", b"\x00\x01\x02binary") == "binary"
