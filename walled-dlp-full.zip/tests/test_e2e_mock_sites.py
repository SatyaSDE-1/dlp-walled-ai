"""End-to-end test: real Chrome (headless, over CDP) + the real injected JS + the real Guard.

The ChatGPT / Perplexity pages are small mock pages served on the *real hostnames* (via
Playwright route fulfilment, so no network is used) with the same DOM hooks our selectors
target. Only the native dialog is replaced by a programmable fake.

Skipped automatically when Chrome is not installed.
"""

import asyncio
import json
import signal
import os
import tempfile
from pathlib import Path

import pytest
from playwright.async_api import async_playwright

from dlp import config
from dlp.browser import BrowserSession, find_chrome, launch_chrome
from dlp.guard import Guard
from samples import make_samples as ms

M = ms.MARKER
PORT = 9333
def _rgb(hex_color: str) -> str:
    h = hex_color.lstrip("#")
    return "rgb(%d, %d, %d)" % tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


COLOR_RGB = _rgb(config.RESPONSE_COLOR)

try:
    find_chrome()
    HAVE_CHROME = True
except FileNotFoundError:
    HAVE_CHROME = False

pytestmark = pytest.mark.skipif(not HAVE_CHROME, reason="Chrome not installed")


class FakeDialog:
    def __init__(self):
        self.answer = True
        self.calls = []

    def __call__(self, d):
        self.calls.append(d)
        return self.answer


PAGE = """<!doctype html><html><body>
<div id="dz" style="min-height:50px">
  %(composer)s
  %(button)s
  <input type="file" id="f" multiple>
</div>
<div id="files"></div>
<script>
const API = %(api)s;
const composer = document.querySelector(%(composer_sel)s);
const sendBtn = document.querySelector(%(button_sel)s);
const filesEl = document.getElementById('files');
async function send() {
  const t = composer.innerText.trim();
  if (!t) return;
  composer.innerText = '';
  try { await fetch(API, {method: 'POST', headers: {'content-type': 'application/json'}, body: JSON.stringify(%(body)s)}); }
  catch (e) { window.__fetchError = String(e); }
  const r = document.createElement('div');
  %(answer_attrs)s
  r.textContent = 'AI answer';
  document.body.appendChild(r);
}
sendBtn.addEventListener('click', send);
composer.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
document.getElementById('f').addEventListener('change', e => { for (const f of e.target.files) filesEl.append('input:' + f.name + ';'); });
document.getElementById('dz').addEventListener('drop', e => { e.preventDefault(); for (const f of e.dataTransfer.files) filesEl.append('drop:' + f.name + ';'); });
composer.addEventListener('paste', e => { for (const f of e.clipboardData.files) filesEl.append('paste:' + f.name + ';'); });
</script></body></html>"""

SITES = {
    "chatgpt": dict(
        url="https://chatgpt.com/",
        api="https://chatgpt.com/backend-api/conversation",
        composer='<div id="prompt-textarea" contenteditable="true" style="border:1px solid #888;min-height:30px"></div>',
        composer_sel="#prompt-textarea",
        button='<button data-testid="send-button">Send</button>',
        button_sel="[data-testid='send-button']",
        body="{messages: [{content: {parts: [t]}}]}",
        answer_attrs="r.setAttribute('data-message-author-role', 'assistant');",
        answer_sel="[data-message-author-role='assistant']",
    ),
    "perplexity": dict(
        url="https://www.perplexity.ai/",
        api="https://www.perplexity.ai/rest/sse/perplexity_ask",
        composer='<div id="ask-input" contenteditable="true" role="textbox" style="border:1px solid #888;min-height:30px"></div>',
        composer_sel="#ask-input",
        button='<button aria-label="Submit">Submit</button>',
        button_sel="button[aria-label='Submit']",
        body="{query_str: t, params: {}}",
        answer_attrs="r.id = 'markdown-content-0'; r.className = 'prose';",
        answer_sel="[id^='markdown-content-']",
    ),
}


def render(spec):
    return PAGE % dict(
        composer=spec["composer"], button=spec["button"], api=json.dumps(spec["api"]),
        composer_sel=json.dumps(spec["composer_sel"]), button_sel=json.dumps(spec["button_sel"]),
        body=spec["body"], answer_attrs=spec["answer_attrs"],
    )


async def settle(page, ms_=700):
    await page.wait_for_timeout(ms_)


async def until(cond, timeout=20.0):
    """Poll an (async) condition - OCR can take a few seconds."""
    loop = asyncio.get_running_loop()
    end = loop.time() + timeout
    while loop.time() < end:
        if await cond():
            return True
        await asyncio.sleep(0.1)
    return False


async def _eq(getter, expected):
    return (await getter()) == expected


def b64(data: bytes) -> str:
    import base64
    return base64.b64encode(data).decode()


async def scenario(ctx, spec, dialog, sent):
    dialog.calls.clear()
    dialog.answer = True
    sent.clear()
    page = await ctx.new_page()
    html = render(spec)
    await page.route(spec["url"], lambda r: r.fulfill(body=html, content_type="text/html"))
    await page.goto(spec["url"])
    sel = spec["composer_sel"]
    files = lambda: page.inner_text("#files")  # noqa: E731

    async def type_prompt(text):
        await page.click(sel)
        await page.keyboard.type(text)

    async def reset():
        await page.evaluate("document.getElementById('files').textContent=''")
        dialog.calls.clear()
        sent.clear()

    # 1 ── clean prompt, Enter: no dialog, request sent, answer coloured
    await type_prompt("what is the capital of France?")
    await page.keyboard.press("Enter")
    await page.wait_for_selector(spec["answer_sel"])
    assert dialog.calls == [] and len(sent) == 1
    colour = await page.eval_on_selector(spec["answer_sel"], "e => getComputedStyle(e).color")
    assert colour == COLOR_RGB, colour
    # descendants are coloured too
    await page.evaluate(f"document.querySelector({json.dumps(spec['answer_sel'])}).innerHTML = '<p><span id=\"inner\">x</span></p>'")
    assert await page.eval_on_selector("#inner", "e => getComputedStyle(e).color") == COLOR_RGB

    # 2 ── sensitive prompt, Enter, Cancel: blocked, text preserved, can edit and resend
    await reset()
    dialog.answer = False
    await type_prompt(f"summarise {M} please")
    await page.keyboard.press("Enter")
    await settle(page)
    assert len(dialog.calls) == 1 and dialog.calls[0].kind == "prompt" and M in dialog.calls[0].label
    assert sent == []
    assert M in await page.inner_text(sel)                     # still in the box
    # user edits the text (removes the marker) and resubmits normally
    await page.click(sel)
    await page.keyboard.press("Control+A")
    await page.keyboard.type("summarise this please")
    dialog.calls.clear()
    await page.keyboard.press("Enter")
    await page.wait_for_function("window.__fetchError === undefined && document.querySelectorAll('div').length > 4")
    await settle(page, 300)
    assert dialog.calls == [] and len(sent) == 1

    # 3 ── sensitive prompt, Enter, Continue: sent exactly once, asked exactly once
    await reset()
    dialog.answer = True
    await type_prompt(f"go ahead {M}")
    await page.keyboard.press("Enter")
    await settle(page, 1200)
    assert len(dialog.calls) == 1 and len(sent) == 1 and M in sent[0]

    # 4 ── sensitive prompt via the Send button
    await reset()
    dialog.answer = False
    await type_prompt(f"button path {M}")
    await page.click(spec["button_sel"])
    await settle(page)
    assert len(dialog.calls) == 1 and sent == []
    dialog.answer = True
    dialog.calls.clear()
    await page.click(spec["button_sel"])
    await settle(page, 1200)
    assert len(dialog.calls) == 1 and len(sent) == 1

    # 5 ── network safety net: a prompt that bypasses the DOM hooks (e.g. regenerate)
    await reset()
    dialog.answer = False
    err = await page.evaluate(
        "fetch(%s,{method:'POST',body:JSON.stringify({query_str:'%s direct', parts:['%s direct']})}).then(()=>null,e=>String(e))"
        % (json.dumps(spec["api"]), M, M)
    )
    assert err and "Failed" in err and sent == [] and len(dialog.calls) == 1
    dialog.answer = True
    dialog.calls.clear()
    await page.evaluate("fetch(%s,{method:'POST',body:JSON.stringify({query_str:'%s direct'})})" % (json.dumps(spec["api"]), M))
    await settle(page)
    assert len(sent) == 1 and len(dialog.calls) == 1

    # 6 ── file picker: every format, Cancel then Continue
    gen = Path(ms.OUT)
    ms.main()
    cases = {
        "sensitive.txt": "text", "sensitive.pdf": "pdf", "sensitive_scanned.pdf": "pdf",
        "sensitive.png": "image", "sensitive.jpg": "image",
    }
    for name, kind in cases.items():
        await reset()
        dialog.answer = False
        await page.set_input_files("#f", str(gen / name))
        await until(lambda: asyncio.sleep(0, len(dialog.calls) > 0))
        await settle(page, 300)
        assert len(dialog.calls) == 1, name
        det = dialog.calls[0]
        assert det.kind == "file" and det.label == name and det.file_type == kind, (name, det)
        assert await files() == "", f"{name} should have been blocked"
        assert await page.eval_on_selector("#f", "e => e.files.length") == 0   # can re-select same file

        dialog.answer = True
        dialog.calls.clear()
        await page.set_input_files("#f", str(gen / name))
        await until(lambda: _eq(files, f"input:{name};"))
        assert len(dialog.calls) == 1
        assert await files() == f"input:{name};", (name, await files())

    # 7 ── clean files upload silently
    for name in ("clean.txt", "clean.pdf", "clean.png"):
        await reset()
        await page.set_input_files("#f", str(gen / name))
        await until(lambda: _eq(files, f"input:{name};"))
        assert dialog.calls == [] and await files() == f"input:{name};", name

    # 8 ── multi-select: only the denied file is dropped
    await reset()
    dialog.answer = False
    await page.set_input_files("#f", [str(gen / "sensitive.txt"), str(gen / "clean.txt")])
    await until(lambda: _eq(files, "input:clean.txt;"))
    assert await files() == "input:clean.txt;"

    # 9 ── drag-and-drop and paste
    drop_js = """([b64, name, type, target]) => {
        const bytes = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
        const dt = new DataTransfer(); dt.items.add(new File([bytes], name));
        const el = document.querySelector(target);
        const ev = type === 'drop'
          ? new DragEvent('drop', {bubbles: true, cancelable: true, dataTransfer: dt})
          : new ClipboardEvent('paste', {bubbles: true, cancelable: true, clipboardData: dt});
        el.dispatchEvent(ev);
    }"""
    data = (gen / "sensitive.txt").read_bytes()
    for evt, target, prefix in (("drop", "#dz", "drop:"), ("paste", sel, "paste:")):
        await reset()
        dialog.answer = False
        await page.evaluate(drop_js, [b64(data), "s.txt", evt, target])
        await settle(page)
        assert len(dialog.calls) == 1 and await files() == "", evt
        dialog.answer = True
        dialog.calls.clear()
        await page.evaluate(drop_js, [b64(data), "s.txt", evt, target])
        await settle(page)
        assert await files() == f"{prefix}s.txt;", (evt, await files())

    await page.close()


def test_end_to_end_on_mock_chatgpt_and_perplexity(monkeypatch):
    profile = tempfile.mkdtemp(prefix="walled-e2e-")
    monkeypatch.setattr(config, "PROFILE_DIR", Path(profile))
    proc = launch_chrome(PORT, extra_args=["--headless=new", "--no-sandbox", "--disable-gpu"])

    async def go():
        dialog = FakeDialog()
        guard = Guard(dialog=dialog)
        session = BrowserSession(guard, port=PORT)
        async with async_playwright() as pw:
            session._pw = None
            browser = await pw.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}")
            ctx = browser.contexts[0]
            sent = []

            async def fake_api(route):                       # lowest-priority route == "the network"
                sent.append(route.request.post_data)
                await route.fulfill(status=200, body="{}", content_type="application/json")

            for site in config.SITES:
                for pattern in site.api_patterns:
                    await ctx.route(pattern, fake_api)
            await session.install(ctx)                       # registered later -> runs first
            for name, spec in SITES.items():
                await scenario(ctx, spec, dialog, sent)
            await browser.close()

    try:
        asyncio.run(go())
    finally:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except Exception:  # noqa: BLE001
            proc.kill()
