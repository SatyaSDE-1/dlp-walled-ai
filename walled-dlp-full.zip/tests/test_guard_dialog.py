import asyncio
import base64
import json
import subprocess
import sys

from dlp import dialog
from dlp.dialog import Detection, build_message
from dlp.guard import ApprovalCache, Guard
from samples import make_samples as ms

M = ms.MARKER


class FakeDialog:
    def __init__(self, answer=True):
        self.answer = answer
        self.calls = []

    def __call__(self, detection):
        self.calls.append(detection)
        return self.answer


def run(coro):
    return asyncio.run(coro)


# ------------------------------------------------------------------ guard logic
def test_clean_prompt_no_dialog():
    d = FakeDialog()
    g = Guard(dialog=d)
    assert run(g.on_prompt({"site": "ChatGPT", "text": "hello"})) == {"allow": True}
    assert d.calls == []


def test_sensitive_prompt_continue_and_cancel():
    d = FakeDialog(True)
    g = Guard(dialog=d)
    assert run(g.on_prompt({"site": "ChatGPT", "text": f"x {M}"}))["allow"] is True
    assert d.calls[0].kind == "prompt" and M in d.calls[0].label
    d.answer = False
    assert run(g.on_prompt({"site": "ChatGPT", "text": f"y {M}"}))["allow"] is False


def test_sensitive_file_dialog_details():
    d = FakeDialog(False)
    g = Guard(dialog=d)
    data = base64.b64encode(ms.SENSITIVE_BODY.encode()).decode()
    out = run(g.on_file({"site": "Perplexity", "name": "plan.txt", "size": 100, "b64": data}))
    assert out == {"allow": False}
    det = d.calls[0]
    assert (det.kind, det.label, det.site) == ("file", "plan.txt", "Perplexity")


def test_clean_file_no_dialog():
    d = FakeDialog()
    g = Guard(dialog=d)
    data = base64.b64encode(ms.CLEAN_BODY.encode()).decode()
    assert run(g.on_file({"site": "x", "name": "a.txt", "size": 5, "b64": data}))["allow"] is True
    assert d.calls == []


def test_oversize_file_is_allowed_with_warning():
    d = FakeDialog()
    g = Guard(dialog=d)
    assert run(g.on_file({"site": "x", "name": "big.bin", "size": 10**9, "b64": None}))["allow"] is True
    assert d.calls == []


# ------------------------------------------------------------ network safety net
def test_network_request_asks_when_not_pre_approved():
    d = FakeDialog(False)
    g = Guard(dialog=d)
    body = json.dumps({"messages": [{"content": {"parts": [f"hi {M}"]}}]}).encode()
    assert run(g.on_request("ChatGPT", body)) is False
    assert len(d.calls) == 1


def test_network_request_skips_dialog_after_page_approval():
    d = FakeDialog(True)
    g = Guard(dialog=d)
    run(g.on_prompt({"site": "ChatGPT", "text": f"hi {M}\n"}))          # user clicked Continue in page
    body = json.dumps({"messages": [{"content": {"parts": [f"hi {M}"]}}]}).encode()
    assert run(g.on_request("ChatGPT", body)) is True
    assert len(d.calls) == 1                                            # not asked twice


def test_network_clean_request_untouched():
    d = FakeDialog()
    g = Guard(dialog=d)
    assert run(g.on_request("ChatGPT", b'{"q": "hello"}')) is True
    assert d.calls == []


def test_approval_cache_expires():
    c = ApprovalCache(ttl=-1)
    c.add("ChatGPT", "abc")
    assert not c.contains("ChatGPT", "abc")


def test_approval_is_per_site():
    d = FakeDialog(True)
    g = Guard(dialog=d)
    run(g.on_prompt({"site": "ChatGPT", "text": f"same text {M}"}))
    body = json.dumps({"q": f"same text {M}"}).encode()
    assert run(g.on_request("ChatGPT", body)) is True and len(d.calls) == 1
    assert run(g.on_request("Perplexity", body)) is True and len(d.calls) == 2   # asked again


def test_dialogs_are_serialised():
    active, peak = 0, 0

    def slow(_d):
        nonlocal active, peak
        import time
        active += 1
        peak = max(peak, active)
        time.sleep(0.05)
        active -= 1
        return True

    async def go():
        g = Guard(dialog=slow)
        await asyncio.gather(*(g.on_prompt({"site": "s", "text": f"{M} {i}"}) for i in range(4)))

    run(go())
    assert peak == 1


# ------------------------------------------------------------------- dialog text
def test_message_for_prompt_and_file():
    p = build_message(Detection("prompt", "ChatGPT", f"secret {M}"))
    assert "TEXT PROMPT" in p and M in p and "Continue" in p and "Cancel" in p
    f = build_message(Detection("file", "Perplexity", "plan.pdf", "page 2 text", "pdf", 2048))
    assert "FILE" in f and "plan.pdf" in f and "2.0 KB" in f and "page 2 text" in f


def test_long_prompt_is_truncated():
    msg = build_message(Detection("prompt", "ChatGPT", "A" * 5000))
    assert len(msg) < 800


def test_mac_dialog_command_and_result(monkeypatch):
    seen = {}

    def fake_run(cmd, **kw):
        seen["cmd"] = cmd
        return subprocess.CompletedProcess(cmd, 0, stdout="Continue\n", stderr="")

    monkeypatch.setattr(dialog.subprocess, "run", fake_run)
    assert dialog._mac("hello") is True
    assert seen["cmd"][0] == "osascript" and "Continue" in " ".join(seen["cmd"])

    monkeypatch.setattr(dialog.subprocess, "run",
                        lambda cmd, **kw: subprocess.CompletedProcess(cmd, 1, stdout="", stderr="-128"))
    assert dialog._mac("hello") is False          # Cancel -> osascript exits non-zero


def test_dialog_failure_blocks(monkeypatch):
    monkeypatch.setattr(dialog.sys, "platform", "darwin")

    def boom(*a, **k):
        raise OSError("no display")

    monkeypatch.setattr(dialog, "_mac", boom)
    assert dialog.confirm(Detection("prompt", "x", M)) is False
