"""Tests for the stdio IPC server (dlp/server.py).

* Dispatcher tests: pure logic, with a fake dialog.
* Process tests: spawn the real server exactly as Electron will and talk to it over its pipes.
"""

import asyncio
import base64
import json
import subprocess
import sys
import time
from pathlib import Path

import pytest

from dlp import config
from dlp.guard import Guard
from dlp.server import PROTOCOL_VERSION, Dispatcher
from samples import make_samples as ms

M = ms.MARKER
ROOT = Path(__file__).resolve().parent.parent


class FakeDialog:
    def __init__(self, answer=True):
        self.answer, self.calls = answer, []

    def __call__(self, d):
        self.calls.append(d)
        return self.answer


def call(dispatcher, op, payload=None, rid=1):
    req = {"id": rid, "op": op}
    if payload is not None:
        req["payload"] = payload
    return asyncio.run(dispatcher.handle(req))


@pytest.fixture
def disp():
    d = FakeDialog(True)
    return Dispatcher(Guard(dialog=d), color="#123456"), d


# ------------------------------------------------------------------ dispatcher
def test_ping(disp):
    r = call(disp[0], "ping")
    assert r["ok"] and r["result"]["pong"] and r["result"]["marker"] == M
    assert r["result"]["protocol"] == PROTOCOL_VERSION


def test_init_script_is_the_shared_builder(disp):
    script = call(disp[0], "init_script")["result"]["script"]
    assert "__WALLED_CONFIG__" in script and M in script and "#123456" in script
    assert "chatgpt.com" in script and "perplexity.ai" in script     # site config comes from config.py


def test_prompt_clean_continue_cancel(disp):
    d, dialog = disp
    assert call(d, "prompt", {"site": "ChatGPT", "text": "hello"})["result"] == {"allow": True}
    assert dialog.calls == []
    assert call(d, "prompt", {"site": "ChatGPT", "text": f"x {M}"})["result"] == {"allow": True}
    dialog.answer = False
    assert call(d, "prompt", {"site": "ChatGPT", "text": f"y {M}"})["result"] == {"allow": False}
    assert len(dialog.calls) == 2


def test_file_ops(disp):
    d, dialog = disp
    dialog.answer = False
    b64 = base64.b64encode(ms.SENSITIVE_BODY.encode()).decode()
    r = call(d, "file", {"site": "Perplexity", "name": "a.txt", "size": 9, "b64": b64})
    assert r["result"] == {"allow": False} and dialog.calls[0].label == "a.txt"
    clean = base64.b64encode(ms.CLEAN_BODY.encode()).decode()
    assert call(d, "file", {"site": "x", "name": "b.txt", "size": 9, "b64": clean})["result"] == {"allow": True}
    assert call(d, "file", {"site": "x", "name": "big", "size": 10**9, "b64": None})["result"] == {"allow": True}


def test_request_safety_net_op(disp):
    d, dialog = disp
    dialog.answer = False
    body = base64.b64encode(json.dumps({"q": f"hi {M}"}).encode()).decode()
    assert call(d, "request", {"site": "ChatGPT", "body_b64": body})["result"] == {"allow": False}


@pytest.mark.parametrize("req,code", [
    ({"id": 1, "op": "nope"}, "unknown_op"),
    ({"id": 1}, "bad_request"),
    ({"op": "ping"}, "bad_request"),
    ({"id": True, "op": "ping"}, "bad_request"),
    ({"id": 1, "op": "ping", "payload": []}, "bad_request"),
    ({"id": 1, "op": "prompt", "payload": {"site": "x", "text": 5}}, "bad_request"),
    ({"id": 1, "op": "prompt", "payload": {"site": "x" * 500, "text": "a"}}, "bad_request"),
    ({"id": 1, "op": "file", "payload": {"site": "x", "name": "a", "size": -1, "b64": None}}, "bad_request"),
    ({"id": 1, "op": "request", "payload": {"site": "x", "body_b64": "!!notbase64!!"}}, "bad_request"),
    ("not an object", "bad_request"),
])
def test_malformed_requests(disp, req, code):
    r = asyncio.run(disp[0].handle(req))
    assert r["ok"] is False and r["error"]["code"] == code
    assert disp[1].calls == []                                   # nothing reached the dialog


# --------------------------------------------------------------- real process
class Proc:
    def __init__(self, *extra):
        self.p = subprocess.Popen(
            [sys.executable, "-u", "-m", "dlp.server", "--no-ocr-warmup", *extra],
            cwd=ROOT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
        self.ready = self.read()

    def read(self):
        line = self.p.stdout.readline()
        assert line, f"server closed stdout; stderr: {self.p.stderr.read()[:500]!r}"
        return json.loads(line)          # raises if anything but protocol JSON is on stdout

    def rpc(self, op, payload=None, rid=1):
        self.p.stdin.write((json.dumps({"id": rid, "op": op, "payload": payload or {}}) + "\n").encode())
        self.p.stdin.flush()
        return self.read()


def test_process_handshake_and_ping():
    s = Proc()
    try:
        assert s.ready["event"] == "ready" and s.ready["protocol"] == PROTOCOL_VERSION
        assert s.rpc("ping")["result"]["pong"] is True
    finally:
        s.p.kill()


def test_process_decisions_use_auto_answer():
    s = Proc("--auto-answer", "cancel")
    try:
        assert s.rpc("prompt", {"site": "ChatGPT", "text": f"a {M}"}, rid=1)["result"] == {"allow": False}
        assert s.rpc("prompt", {"site": "ChatGPT", "text": "fine"}, rid=2)["result"] == {"allow": True}
    finally:
        s.p.kill()


def test_stdout_stays_clean_even_when_libraries_log_and_print():
    """OCR (RapidOCR) is chatty. Scan an image and a scanned PDF; every stdout line must still be protocol JSON."""
    s = Proc("--auto-answer", "continue")
    try:
        for i, (name, data) in enumerate([("s.png", ms.image_bytes(ms.SENSITIVE_BODY, "PNG")),
                                          ("s.pdf", ms.pdf_from_image(ms.SENSITIVE_BODY))], start=1):
            r = s.rpc("file", {"site": "ChatGPT", "name": name, "size": len(data),
                               "b64": base64.b64encode(data).decode()}, rid=i)
            assert r["id"] == i and r["ok"] and r["result"] == {"allow": True}
    finally:
        s.p.kill()


def test_concurrent_requests_are_answered_independently():
    s = Proc("--auto-answer", "continue")
    try:
        for i in range(1, 6):
            s.p.stdin.write((json.dumps({"id": i, "op": "ping"}) + "\n").encode())
        s.p.stdin.flush()
        assert sorted(s.read()["id"] for _ in range(5)) == [1, 2, 3, 4, 5]
    finally:
        s.p.kill()


def test_bad_json_line_does_not_kill_server():
    s = Proc()
    try:
        s.p.stdin.write(b"{this is not json\n")
        s.p.stdin.flush()
        assert s.read()["error"]["code"] == "bad_json"
        assert s.rpc("ping")["ok"]
    finally:
        s.p.kill()


def test_exits_when_parent_closes_the_pipe():
    s = Proc()
    s.p.stdin.close()                                            # what happens when Electron dies
    assert s.p.wait(timeout=10) == 0


def test_shutdown_op_exits_cleanly():
    s = Proc()
    assert s.rpc("shutdown")["ok"]
    assert s.p.wait(timeout=10) == 0
