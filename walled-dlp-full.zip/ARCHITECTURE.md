# Architecture

## Goal and constraints

Inspect prompts and files **before** they are transmitted by ChatGPT / Perplexity, ask the user through a
**native** dialog, and enforce the answer - without breaking the sites.

### Why not a MITM proxy?
A proxy sees bytes only after the site has already decided to send them (cancelling means an error toast
and a lost prompt), needs a trusted root CA, and both sites sit behind Cloudflare, which fingerprints
non-browser TLS clients. Instead the app **controls a real Chrome over the DevTools Protocol (CDP)**: the
interception happens inside the page, before the request exists, and the browser's own TLS is untouched.

## Components

```
                ┌──────────────────────── Chrome (dedicated profile, --remote-debugging-port) ─────────────────────────┐
                │  chatgpt.com / perplexity.ai tab                                                                     │
                │   ┌─────────────────────────── inject/guard.js (runs before site code) ──────────────────────────┐   │
 user ─────────►│   │  keydown(Enter) / click(Send)  ──┐                                                           │   │
                │   │  change / drop / paste (files) ──┼─► window.__walledScan({kind, ...})  ──────────────┐      │   │
                │   │  adoptedStyleSheets: response colour                                               │      │   │
                │   └────────────────────────────────────────────────────────────────────────────────────┼──────┘   │
                │   fetch → /backend-api/conversation  ───────────────────────┐ (paused by context.route) │          │
                └─────────────────────────────────────────────────────────────┼───────────────────────────┼──────────┘
                                                CDP (Playwright connect_over_cdp)                         │
                ┌─────────────────────────────────────────────────────────────▼───────────────────────────▼──────────┐
                │ Python                                                                                              │
                │  browser.py  ── expose_function / route / add_init_script                                           │
                │      └─► guard.py ──► scanner.py (text · PDF · image) ──► ocr.py                                    │
                │               └────► dialog.py ──► osascript / zenity / kdialog / dialog_tk.py   (native window)    │
                └─────────────────────────────────────────────────────────────────────────────────────────────────────┘
```

| Module | Responsibility |
|---|---|
| `browser.py` | Launch/attach Chrome, register the three hooks on the browser context. No policy. |
| `inject/guard.js` | Detect user actions, hold them, ask Python, replay or drop. No scanning of PDFs/images. |
| `guard.py` | Policy: scan, show dialog, remember approvals, serialise dialogs. No browser knowledge. |
| `scanner.py` / `ocr.py` | Pure functions of bytes → "marker found?". No UI. |
| `dialog.py` | Pure UI: `confirm(Detection) -> bool`. |
| `config.py` | Everything site-specific. |

Each layer can be tested alone: `Guard` takes an injectable dialog, the scanner needs no browser, and the
end-to-end test swaps only the dialog.

## Prompt interception

Two independent layers.

**1. Page hook (primary, gives the right UX).** Capture-phase listeners on `window` run before the site's
own handlers. On Enter (no Shift) in the composer, or a click on the Send button:

1. Read the composer text. **No marker → the event is not touched at all** (zero interference for normal use).
2. Marker present → `preventDefault` + `stopImmediatePropagation`; the site never sees the submit.
3. `await window.__walledScan({kind:'prompt', text})` → Python scans, shows the native dialog.
4. **Continue** → replay: click the real Send button (fallback: synthetic Enter) with a `bypass` flag so the
   hook ignores its own replay. The site handles it as a genuine submit; content is unmodified.
5. **Cancel** → nothing is replayed. The prompt is still in the box; the user can edit or retry.

**2. Network safety net.** `context.route` pauses the POST that carries the prompt
(`/backend-api/conversation`, `/rest/sse/perplexity_ask`). If its JSON contains the marker and the user has
not already approved that exact text *for that site* in the last 3 minutes, Python asks; Cancel aborts the
request. This covers paths the DOM hooks cannot see (regenerate, edit message, synthetic submits) and means
**nothing containing the marker is transmitted without an explicit Continue**. Because of the approval
cache, a normal Continue produces exactly one dialog, not two.

## File interception

Hooks on the three ways a file can enter the page: `<input type=file>` (`input` + `change`), `drop`, `paste`.

1. The event is swallowed. Each file is read (`FileReader`) and sent to Python as base64
   (`{kind:'file', name, size, b64}`); files over 30 MB are skipped with a warning.
2. `Guard.on_file` scans in a worker thread (OCR is CPU-bound) so the event loop stays responsive.
3. Marker found → native dialog. **Cancel** removes that file only; **Continue** keeps it.
4. Approved files are replayed: file inputs get `input.files = DataTransfer.files` (when some were
   dropped) and fresh `input`/`change` events; drop/paste get a new event carrying a new `DataTransfer`.
   Denied selections reset the input (`value = ''`) so the same file can be picked again.

Multi-select works per file: one sensitive file in a selection of three drops only that one.

## Detection (`scanner.py`)

File type is decided by **magic bytes**, not extension (a PDF renamed `.txt` is still a PDF).

| Type | Strategy |
|---|---|
| any | Raw byte search for the marker in UTF-8 / UTF-16 LE / BE (also catches metadata and uncompressed streams) |
| text | the raw search above |
| PDF | `pypdf` text per page + metadata → OCR of embedded images → pages with no text are rendered by `pypdfium2` and OCR'd (vector-drawn text) |
| image | OCR (rapidocr, Tesseract fallback); upscaled if small, transparency flattened, GIF/WebP frames sampled |
| docx/xlsx/pptx/zip | each member searched (bonus) |

Text from PDF extraction and OCR is matched tolerantly (`WALLED[ _.-]{0,3}SENSITIVE`) since both routinely
mangle underscores. Typed prompts and plain text use the exact marker. Work is bounded (max OCR images and
rendered pages per PDF). The scanner never raises: a corrupt file yields `found=False, error=...`.

## Native dialog

`confirm(Detection)` is blocking and returns Continue/Cancel. It states **prompt vs file**, the
**destination site**, the **prompt text (truncated) or file name** (plus type, size and *where* the marker
was found), with buttons labelled exactly *Continue* and *Cancel* (Cancel is the default).

* macOS: `osascript` `display dialog` - a real system dialog.
* Linux: `zenity`, else `kdialog`. Windows (and any fallback): a Tk window in a child process.

Dialogs run in a worker thread behind an `asyncio.Lock`: the event loop never blocks, and two dialogs can
never be on screen at once. If a dialog cannot be shown, the result is **Cancel** (fail closed).

## Response colour

`guard.js` creates a `CSSStyleSheet` and adds it to `document.adoptedStyleSheets` with
`:is(<response selectors>), :is(<response selectors>) * { color: … !important }`. A constructable sheet is
not blocked by Content-Security-Policy (an injected `<style>` tag can be), and a stylesheet - rather than
per-node edits - applies to streamed and future messages automatically with no observers. Selectors per
site are in `config.py`.

## Reliability notes

* The init script runs before any site script; the Python bridge is exposed per context so it also covers
  tabs opened later. Existing ChatGPT/Perplexity tabs are reloaded once at start-up.
* Replays are flagged (`bypass`), so the hooks cannot loop on themselves.
* Only narrow URL patterns are routed; all other traffic is untouched. Handlers use `route.fallback()`
  so they coexist with other route handlers.
* Bridge or Python errors fail **open** (the user is not locked out of the site); only an explicit Cancel
  or an undisplayable dialog blocks.

## Testing

* 31 unit tests (scanner, guard, dialog).
* 1 end-to-end test: real headless Chrome over CDP, the real `guard.js` and `Guard`, mock ChatGPT and
  Perplexity pages on the real hostnames. Covers Enter and Send-button submit, Continue and Cancel, edit
  and resend after Cancel, the network safety net, txt/PDF/scanned-PDF/PNG/JPG, multi-select,
  drag-and-drop, paste, and response colour on both sites.
* Not automated: the real macOS dialog and the live sites (see README, *Known limitations*).


---

# Desktop app (Electron) architecture - Step 2, in progress

```
┌───────────────────────── Electron main process (TypeScript) ─────────────────────────┐
│  main.ts          window, trusted IPC (sender check), lifecycle                      │
│  site-views.ts    one WebContentsView per site, layout, navigation/permission policy │
│  python-backend.ts  spawn / handshake / request-response / crash-restart / kill      │
└──────┬───────────────────────────────┬───────────────────────────────┬──────────────┘
       │ preload-shell.cjs             │ preload-site.cjs (no API yet) │ stdin/stdout, JSON lines
┌──────▼─────────────┐   ┌─────────────▼──────────────┐   ┌────────────▼───────────────┐
│ React toolbar      │   │ WebContentsView: ChatGPT   │   │ python -m dlp.server       │
│ (trusted, local)   │   │ WebContentsView: Perplexity│   │  Dispatcher -> Guard ->    │
│ tabs, nav, status  │   │ (untrusted, sandboxed)     │   │  Scanner / OCR / dialog    │
└────────────────────┘   └────────────────────────────┘   └────────────────────────────┘
```

* **No duplicated logic.** `dlp/server.py` only validates a request and calls the existing
  `Guard.on_prompt / on_file / on_request`. The page-side script is the same `guard.js` +
  `injector.build_init_script()`, fetched from Python (`init_script` op), so site selectors live only in `config.py`.
* **IPC choice.** An anonymous pipe owned by the Electron parent: no TCP port, nothing for another
  local process to connect to, and the child exits when the parent dies (stdin EOF). stdout is reserved for
  the protocol (fd 1 is redirected to stderr at start-up so a stray `print` or OCR log cannot corrupt it).
* **Trust boundaries.** Website content: `contextIsolation`, no `nodeIntegration`, `sandbox`, no
  `webviewTag`, deny-by-default permissions, top-level navigation restricted to an https allowlist, new
  windows denied. The toolbar's API is a fixed set of methods (no generic backend call) and every
  privileged IPC handler checks `event.sender` is the toolbar window.
* **Fail-safe for the backend.** If Python is down the toolbar says so; calls fail fast with a clear
  error rather than hanging, and crashes are retried with back-off (5 in 60 s, then "Unavailable").

Not implemented yet: the bridge from the site views to Python (prompt / file interception), the dialog
flow, and response colouring inside the embedded views.
