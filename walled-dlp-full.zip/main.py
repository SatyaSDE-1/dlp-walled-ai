"""Walled DLP - entry point.

    python main.py                 # launch Chrome with protection on ChatGPT + Perplexity
    python main.py --attach        # attach to a Chrome you already started with --remote-debugging-port
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys

from dlp import config
from dlp.browser import BrowserSession, cdp_alive, launch_chrome
from dlp.guard import Guard
from dlp.scanner import Scanner


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Lightweight DLP guard for ChatGPT and Perplexity web apps.")
    p.add_argument("--port", type=int, default=config.CDP_PORT, help="Chrome remote-debugging port (default %(default)s)")
    p.add_argument("--attach", action="store_true", help="Do not launch Chrome; attach to one already listening on --port")
    p.add_argument("--chrome-path", help="Path to the Chrome / Chromium / Edge executable")
    p.add_argument("--color", default=config.RESPONSE_COLOR, help="CSS colour for AI responses (default %(default)s)")
    p.add_argument("--no-open", action="store_true", help="Do not open the ChatGPT / Perplexity tabs automatically")
    p.add_argument("-v", "--verbose", action="store_true", help="Debug logging (also logs from the page)")
    return p.parse_args(argv)


async def run(args: argparse.Namespace) -> int:
    scanner = Scanner()
    guard = Guard(scanner)

    if not cdp_alive(args.port):
        if args.attach:
            print(f"No Chrome is listening on port {args.port}.", file=sys.stderr)
            return 2
        launch_chrome(args.port, args.chrome_path)
    else:
        logging.getLogger("dlp").info("Attaching to Chrome on port %d", args.port)

    session = BrowserSession(guard, port=args.port, color=args.color, debug=args.verbose)
    await session.start(open_sites=not args.no_open)

    # Load the OCR models now so the first image / PDF check is not slow.
    asyncio.get_running_loop().run_in_executor(None, lambda: scanner.ocr.available)

    print("\nWalled DLP is active.")
    print(f"  Marker           : {config.MARKER}")
    print(f"  Protected sites  : {', '.join(s.name for s in config.SITES)}")
    print("  Use the Chrome window that just opened. Close it (or press Ctrl+C here) to stop.\n")

    try:
        await session.disconnected.wait()
    finally:
        await session.stop()
    return 0


def main() -> int:
    args = parse_args()
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s  %(levelname)-7s %(message)s",
        datefmt="%H:%M:%S",
    )
    logging.getLogger("RapidOCR").setLevel(logging.WARNING)
    try:
        return asyncio.run(run(args))
    except KeyboardInterrupt:
        return 0
    except FileNotFoundError as exc:
        print(exc, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
