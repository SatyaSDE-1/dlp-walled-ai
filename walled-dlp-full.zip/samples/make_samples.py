"""Generate demo / test files in ./samples/generated.

    python samples/make_samples.py

Creates, for each supported format, one file WITH the marker and one WITHOUT:
    text   : sensitive.txt              clean.txt
    pdf    : sensitive.pdf              clean.pdf          (real text layer)
             sensitive_scanned.pdf                         (image-only, needs OCR)
    image  : sensitive.png / .jpg       clean.png
"""

from __future__ import annotations

import io
import sys
from pathlib import Path

MARKER = "WALLED_SENSITIVE"
OUT = Path(__file__).resolve().parent / "generated"

SENSITIVE_BODY = f"Project Falcon budget review.\nInternal reference: {MARKER}\nDo not share outside the company."
CLEAN_BODY = "Weekly lunch menu.\nMonday: pasta. Tuesday: salad.\nNothing confidential here."


def text_image(body: str, size=(1100, 360), font_size=44):
    from PIL import Image, ImageDraw, ImageFont

    img = Image.new("RGB", size, "white")
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default(size=font_size)
    draw.multiline_text((40, 40), body, fill="black", font=font, spacing=14)
    return img


def pdf_with_text(body: str) -> bytes:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    y = 780
    for line in body.splitlines():
        c.drawString(72, y, line)
        y -= 24
    c.save()
    return buf.getvalue()


def pdf_from_image(body: str) -> bytes:
    buf = io.BytesIO()
    text_image(body).save(buf, format="PDF", resolution=150)
    return buf.getvalue()


def image_bytes(body: str, fmt: str) -> bytes:
    buf = io.BytesIO()
    text_image(body).save(buf, format=fmt)
    return buf.getvalue()


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    files = {
        "sensitive.txt": SENSITIVE_BODY.encode(),
        "clean.txt": CLEAN_BODY.encode(),
        "sensitive.pdf": pdf_with_text(SENSITIVE_BODY),
        "clean.pdf": pdf_with_text(CLEAN_BODY),
        "sensitive_scanned.pdf": pdf_from_image(SENSITIVE_BODY),
        "sensitive.png": image_bytes(SENSITIVE_BODY, "PNG"),
        "sensitive.jpg": image_bytes(SENSITIVE_BODY, "JPEG"),
        "clean.png": image_bytes(CLEAN_BODY, "PNG"),
    }
    for name, data in files.items():
        (OUT / name).write_bytes(data)
        print(f"  wrote {OUT.name}/{name} ({len(data):,} bytes)")


if __name__ == "__main__":
    sys.exit(main())
