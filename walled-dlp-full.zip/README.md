# Walled DLP

A lightweight desktop Data-Loss-Prevention guard for the **ChatGPT** (`chatgpt.com`) and
**Perplexity** (`www.perplexity.ai`) web apps, written in Python.

It watches what you are about to send, looks for the marker **`WALLED_SENSITIVE`**, and if it finds
it shows a **native desktop dialog** with **Continue / Cancel** *before* anything leaves the browser.
It also recolours every AI response.

| Requirement | How it is met |
|---|---|
| Inspect text prompts before submit | Page hook on Enter / Send button + network safety net |
| Inspect uploads before transmit | Page hooks on file picker, drag-and-drop, paste |
| Text, PDF, image files | Raw scan + PDF text layer + OCR (embedded images and rendered pages) |
| Native confirmation dialog | macOS `osascript` dialog (Linux: zenity/kdialog, Windows: Tk window) |
| Continue / Cancel | Continue replays the original action untouched; Cancel drops it, text stays editable |
| Recolour AI responses | Constructable stylesheet injected on both sites (CSP-proof) |

---

## Setup (macOS)

Requirements: **Python 3.9+** and **Google Chrome**.

```bash
cd walled-dlp
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

No `playwright install` is needed - the app drives your installed Chrome over the DevTools protocol.
OCR (`rapidocr`) ships its models inside the pip package, so there is no Tesseract install either.
(If you already have Tesseract, it is used as a fallback.)

## Run

```bash
python main.py
```

A Chrome window opens with ChatGPT and Perplexity tabs and the terminal prints
`Walled DLP is active`. **Use that window.** Log in once - the login is kept in a dedicated
profile (`~/.walled-dlp/chrome-profile`), separate from your normal Chrome.

> Why a separate profile? Chrome 136+ refuses remote debugging on the default profile, and it keeps
> your everyday browsing completely untouched. Other Chrome windows are not monitored.

Options: `--color "#2f9e44"` (response colour), `--attach` (attach to a Chrome you started yourself
with `--remote-debugging-port=9222`), `--chrome-path`, `--no-open`, `-v` (verbose).

Stop with `Ctrl+C` or by closing the Chrome window.

## Try it (also the demo script)

```bash
python samples/make_samples.py     # writes samples/generated/*  (already included in the repo)
```

On **each** of ChatGPT and Perplexity:

1. Send `What is the capital of France?` -> goes through, no dialog; the answer is **orange**.
2. Type `please summarise WALLED_SENSITIVE notes`, press Enter -> native dialog.
   **Cancel** -> nothing is sent, the text is still in the box. Edit / Enter again.
   **Continue** -> it is sent normally.
3. Attach each file (the `+` / paperclip button, or drag-and-drop, or paste):

   | File | Expected |
   |---|---|
   | `sensitive.txt` | dialog (file name, "text") |
   | `sensitive.pdf` | dialog ("page 1 text") |
   | `sensitive_scanned.pdf` | dialog ("image (OCR)") |
   | `sensitive.png`, `sensitive.jpg` | dialog ("text in image (OCR)") |
   | `clean.txt`, `clean.pdf`, `clean.png` | attached silently |

   Cancel -> file is not attached (and can be picked again). Continue -> attached as normal.

## Tests

```bash
pip install -r requirements-dev.txt
python -m pytest tests -v
```

* `test_scanner.py` - text / PDF / scanned PDF / PNG / JPG / zip / corrupt input
* `test_guard_dialog.py` - decision logic, approval cache, dialog text, macOS command building
* `test_e2e_mock_sites.py` - **real Chrome over CDP** + the real injected JS against mock
  ChatGPT/Perplexity pages (same hostnames, same selectors). Only the dialog is faked.
  Skipped automatically if Chrome is missing.

## Project layout

```
walled-dlp/
├── main.py                 CLI entry point
├── dlp/
│   ├── config.py           marker, colour, per-site URLs / selectors / API patterns
│   ├── scanner.py          marker detection: text, PDF, images, zip containers
│   ├── ocr.py              OCR back-ends (rapidocr -> tesseract), lazy-loaded
│   ├── guard.py            decision engine: scan -> dialog -> allow/block, approval cache
│   ├── dialog.py           native dialog (osascript / zenity / kdialog / Tk)
│   ├── dialog_tk.py        Tk window (Windows + fallback), run as a child process
│   ├── browser.py          Chrome launch + Playwright-over-CDP wiring
│   ├── injector.py         builds the injected script + config
│   └── inject/guard.js     page-side hooks: prompts, files, response colour
├── samples/make_samples.py demo / test file generator   (+ samples/generated/)
├── tests/
├── ARCHITECTURE.md
└── requirements*.txt
```

## Known limitations

* **Site markup changes.** ChatGPT and Perplexity change their DOM from time to time. All selectors
  live in `dlp/config.py`; if a hook stops matching, that is the only file to touch. Even then the
  network safety net still blocks sensitive prompts.
* Files are checked at **attach time** (before the site uploads them). A page that starts an upload
  through a path other than the file input / drop / paste is not covered.
* The marker is matched exactly (case-sensitive) in prompts and plain text. In OCR'd / PDF-extracted
  text a tolerant match is used (`WALLED SENSITIVE`, `WALLED-SENSITIVE`), because OCR often loses
  underscores.
* Files over 30 MB are not inspected (logged and allowed) - `MAX_FILE_BYTES` in `config.py`.
* If the dialog cannot be shown at all, the action is **blocked** (fail closed).

---

## Desktop app (Electron + React) - work in progress

A standalone app that embeds ChatGPT and Perplexity in its own Chromium window (no external Chrome,
no extension) and reuses the Python scanner / guard / dialog code through a managed child process.
The original Playwright mode above still works unchanged.

```bash
# once: Python deps (as above) + Node 20+
cd desktop && npm install
npm run dev          # Vite dev server + Electron
npm start            # production build + Electron
```

Python is found via `$WALLED_PYTHON`, then `../.venv/bin/python`, then `python3`.

### Status (what is built and what is verified)

| Step | State |
|---|---|
| Electron + React + TypeScript + Vite project | done, `npm run typecheck` clean |
| ChatGPT / Perplexity in `WebContentsView`s, tab navigation, back / forward / reload | done, tested against **local mock pages** |
| Security: contextIsolation, no nodeIntegration, sandbox, navigation allowlist, permission denial, trusted-sender IPC | done, tested |
| Python backend as managed child process (stdio JSON IPC, restart on crash, no orphans) | done, tested |
| Prompt / file interception inside the embedded views | **not started** (next step) |
| Native Continue / Cancel from the desktop app | **not started** (backend op exists; not wired to the views) |
| Response colour inside the embedded views | **not started** (next step) |
| Behaviour on the *real* chatgpt.com / perplexity.ai | **not tested** (needs a networked machine) |

### Tests

```bash
python -m pytest tests -v                  # 54 Python tests (scanner, guard, dialog, IPC server, Playwright e2e)
cd desktop
npm run test:unit                          # URL allowlist
npm run test:e2e                           # real Electron + real Python child, mock sites (needs a display; uses xvfb-run on Linux)
```

On macOS replace `xvfb-run -a` in the `test:e2e` script with nothing (a display exists).
